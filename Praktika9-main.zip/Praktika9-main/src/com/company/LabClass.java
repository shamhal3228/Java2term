package com.company;

public class LabClass {

    public static void main(String[] args) throws EmptyStringException, StudentNotFoundException {

            //INNCheck obj=new INNCheck();

            //new LabClassUI().setVisible(true);
    }
}
