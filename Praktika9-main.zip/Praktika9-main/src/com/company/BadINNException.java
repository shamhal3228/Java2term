package com.company;

public class BadINNException extends Exception {

    BadINNException(String errorMessage){
        super(errorMessage);
    }
}
