package com.company;

public interface Movable {
    void moveUp();
    void moveDown();
    void moveLeft();
    void moveRight();
}